
# coding: utf-8

# In[25]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv("C:/Users/derek/Desktop/POC/data/berek.csv")



# In[26]:


##Performing column operation on bugs i.e., o if bugs =0 and 1 if bugs >=1.
def bug_column_cleaner(x):
    
    if int(x)==0:
        return 0
    else:
        return 1
bug_modified =dataset[['bug']].applymap(bug_column_cleaner)
dataset=dataset.assign(bug_modified=bug_modified.values) # creating the bug column as per the requirement
del dataset['bug'] # deleting the bug column and replacing with the "bug_modified" column.


# In[28]:


X = dataset.iloc[:,3:23].values
y = dataset.iloc[:, 23].values


my_tab = pd.crosstab(index=dataset["bug_modified"], columns="count") 

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.30, random_state = 0)



from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)



import scipy.cluster.hierarchy as sch
Z = sch.linkage(X_train, method = 'ward')
den = sch.dendrogram(Z)
plt.title('Dendrogram for the clustering of the dataset for bug and not bug')
plt.xlabel('bug kernals')
plt.ylabel('Euclidean distance')
plt.show()


# Fitting Hierarchical Clustering to the dataset
from sklearn.cluster import AgglomerativeClustering
hc = AgglomerativeClustering(n_clusters = 2, affinity = 'euclidean', linkage = 'ward')
y_hc = hc.fit_predict(X_train)
y_pred = np.array(y_hc)


#confusion matrix and classification report for taining set 
from sklearn.metrics import confusion_matrix,classification_report,accuracy_score
cm_train = confusion_matrix(y_train, y_pred)
report_train = classification_report(y_train, y_pred)
accuracy_train = accuracy_score(y_train, y_pred)




# for test set
y_hc_test= hc.fit_predict(X_test)
y_pred_test = np.array(y_hc_test)


#confusion matrix and classification report for test set
from sklearn.metrics import confusion_matrix,classification_report,accuracy_score
cm_test = confusion_matrix(y_test, y_pred_test)
report_test = classification_report(y_test, y_pred_test)
accuracy_test = accuracy_score(y_test, y_pred_test)

