import numpy as np
import pandas as pd
import sklearn as sk
import matplotlib as plt
from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.metrics import confusion_matrix, accuracy_score, recall_score, precision_score, f1_score, completeness_score
from sklearn.model_selection import train_test_split, cross_val_score, cross_val_predict, KFold
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeClassifier

df1 = pd.read_csv(r'C:/Users/derek/Desktop/POC/data/berek.csv')


df = df1

df.describe()



def see(df):
    for x in df.columns:
        plt.figure.Figure()
        yield plt.pyplot.hist(df[x], bins = 5)

gen = see(df) # generator

gen2 = (plt.pyplot.hist(df[x], bins = 5) for x in df.columns)


#def col():
#    for x in df.columns:
#        yield x    
#
#gen1 = col()
#
#plt.pyplot.hist(df[next(gen1)], bins = 5)

## useful/useless columns

colsNeed = [col for col in df.columns if col not in ['name','version','bug','name.1']]
colsNotNeed = [col for col in df.columns if col in ['name','version','bug','name.1']]

X_notreqd_df = df[colsNotNeed]
Xdf = df[colsNeed]
ydf = df[['bug']]

## converting bugs to 2 classes : Bug | No-Bug     # 7, 54, 55
temp = np.array(ydf)
newtemp = np.asarray([1 if x>0 else 0 for x in temp])

ydf = pd.DataFrame(newtemp, columns = ['bug'])

## Merging Xdf and ydf

dff = pd.concat([Xdf, ydf], axis = 1)

## k-fold


X_train, X_test, y_train, y_test = train_test_split(Xdf, ydf, test_size=0.3)
print (X_train.shape, y_train.shape)
print (X_test.shape, y_test.shape)

plt.pyplot.hist(ydf['bug'].transpose().value_counts())

# decision trees
try:
    dt_model = DecisionTreeClassifier()
    
    # Running a grid search
    param_grid = {
                  "max_depth": [2, 4,None],
                  "max_features": ["log2", "auto", "sqrt"],
                  "min_samples_split": [2, 3, 5, 10]
                  }
    
    grid_search = GridSearchCV(dt_model, param_grid = param_grid, n_jobs = 1, cv = 6, refit = True)
    grid_search.fit(X_train, y_train.values.ravel())
    g_scores = grid_search.grid_scores_, grid_search.best_params_, grid_search.best_score_
    print("Cross-val results for decision trees:")
    print(grid_search.cv_results_)
    print("Best params: "+ str(grid_search.best_params_))
    # Setting our Decision  Tree with the above found best params -
    dt_model = DecisionTreeClassifier(
                                      max_depth = g_scores[1].get('max_depth'),
                                      max_features = g_scores[1].get('max_features'),
                                      min_samples_split = g_scores[1].get('min_samples_split')
                                      )
 
except Exception as e:
    print("Error encountered! ERROR: "+ str(e))
    print("Therefore, avoiding grid serarch and continuing execution...")
    dt_model = DecisionTreeClassifier(max_depth = None, 
                                     max_features = 'auto', 
                                     min_samples_split = 2)
                                     
dt_model.n_features_ = len(X_train.columns)
dt_model.fit(X_train, y_train.values.ravel())
##                      ----- end of Model Building -----

# Predicting on train set =and holdout test set
trainPrediction = dt_model.predict(X_train)
testPrediction = dt_model.predict(X_test)
# Conf mat and results:

cmTrainDT = confusion_matrix(y_train, trainPrediction)
cmTestDT = confusion_matrix(y_test, testPrediction)
accuracyTrainDT = accuracy_score(y_train, trainPrediction)
accuracyTestDT = accuracy_score(y_test, testPrediction)
recallTrainDT = recall_score(y_train, trainPrediction)
recallTestDT = recall_score(y_test, testPrediction)
precisionTrainDT = precision_score(y_train, trainPrediction)
precisionTestDT = precision_score(y_test, testPrediction)
f1ScoreTrainDT = f1_score(y_train, trainPrediction)
f1ScoreTestDT = f1_score(y_test, testPrediction)

print("Decision trees final results: [TRAIN] -- [TEST]")
print("Accuracy: {} -- {}".format(accuracyTrainDT, accuracyTestDT))
print("Recall: {} -- {}".format(recallTrainDT, recallTestDT))
print("Precision: {} -- {}".format(precisionTrainDT, precisionTestDT))
print("F1 Score: {} -- {}".format(f1ScoreTrainDT, f1ScoreTestDT))

##########   Extra Section - ignore
#    if all_cvtrainCluster_DF is None:
#        all_cvtrainCluster_DF = pd.DataFrame(cvtrainCluster)
#        print(all_cvtrainCluster_DF.shape)
#    if all_cvtestCluster_DF is None:
#        all_cvtestCluster_DF = pd.DataFrame(cvtestCluster)
#    all_cvtrainCluster_DF = pd.concat([all_cvtrainCluster_DF, cvtrainCluster], axis = 1)
#    all_cvtestCluster_DF = pd.concat([all_cvtestCluster_DF, cvtestCluster], axis = 1)