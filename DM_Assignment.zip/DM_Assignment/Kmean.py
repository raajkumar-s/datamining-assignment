import numpy as np
import pandas as pd
import sklearn as sk
import matplotlib as plt
from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.metrics import confusion_matrix, accuracy_score, recall_score, precision_score, f1_score, completeness_score
from sklearn.model_selection import train_test_split, cross_val_score, cross_val_predict, KFold
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeClassifier

df1 = pd.read_csv(r'C:/Users/derek/Desktop/POC/data/berek.csv')

df = df1

df.describe()



def see(df):
    for x in df.columns:
        plt.figure.Figure()
        yield plt.pyplot.hist(df[x], bins = 5)

gen = see(df) # generator

gen2 = (plt.pyplot.hist(df[x], bins = 5) for x in df.columns)


#def col():
#    for x in df.columns:
#        yield x    
#
#gen1 = col()
#
#plt.pyplot.hist(df[next(gen1)], bins = 5)

## useful/useless columns

colsNeed = [col for col in df.columns if col not in ['name','version','bug','name.1']]
colsNotNeed = [col for col in df.columns if col in ['name','version','bug','name.1']]

X_notreqd_df = df[colsNotNeed]
Xdf = df[colsNeed]
ydf = df[['bug']]

## converting bugs to 2 classes : Bug | No-Bug     # 7, 54, 55
temp = np.array(ydf)
newtemp = np.asarray([1 if x>0 else 0 for x in temp])

ydf = pd.DataFrame(newtemp, columns = ['bug'])

## Merging Xdf and ydf

dff = pd.concat([Xdf, ydf], axis = 1)

## k-fold


X_train, X_test, y_train, y_test = train_test_split(Xdf, ydf, test_size=0.3)
print (X_train.shape, y_train.shape)
print (X_test.shape, y_test.shape)

plt.figure.Figure()
plt.pyplot.hist(ydf['bug'].transpose().value_counts())

# Performing 5-fold cross vaiidation for all algos

#                      K-MEANS

kmeansModels = {}
acc_kmeans_all = {}
for i in range(2,8):
    kmeans = KMeans(n_clusters = i, random_state = 0).fit(X_train)
    acc_kmeans = cross_val_score(kmeans, X_train, y_train.values.flatten(), scoring='completeness_score', cv = i).mean() * 100
    kmeansModels[i] = kmeans
    acc_kmeans_all[i] = acc_kmeans


bestKMeansKey = max(acc_kmeans_all, key=acc_kmeans_all.get)
# Extra info
#print(kmeansModels[bestKMeansKey].labels_)
#print(kmeansModels[bestKMeansKey].cluster_centers_)
bestKMeansModel = kmeansModels[bestKMeansKey]

# KMeans metrics



# KMeans2
#kmeans2Models = 
kf = KFold(n_splits=6)
iteration = 1
all_acc_Train = []
all_acc_Test = []
all_completeness_Train = []
all_completeness_Test = []
all_recall_Train = []
all_recall_Test = []
all_precision_Train = []
all_precision_Test = []
all_f1Score_Train = []
all_f1Score_Test = []

for train_index, test_index in kf.split(X_train):
    print("CV Iteration", iteration, "  CV TRAIN:", train_index, "  CV TEST:", test_index)
    X_cv_train, X_cv_test = X_train.iloc[train_index], X_train.iloc[test_index]
    y_cv_train, y_cv_test = y_train.iloc[train_index], y_train.iloc[test_index]
    kmeans2 = KMeans(n_clusters = 2, random_state = 0).fit(X_cv_train)
    cvtrainCluster = pd.DataFrame(kmeans2.predict(X_cv_train), columns = ['PredictedCluster'])
    cvtestCluster = pd.DataFrame(kmeans2.predict(X_cv_test), columns = ['PredictedCluster'])

    realVScvtrainCluster = pd.concat([pd.DataFrame(y_cv_train.values.flatten(), \
         columns = ['Actual']), cvtrainCluster], axis = 1)
    realVScvtestCluster = pd.concat([pd.DataFrame(y_cv_test.values.flatten(), \
         columns = ['Actual']), cvtestCluster], axis = 1)
         
    confmatcvTrain = confusion_matrix(realVScvtrainCluster.iloc[:,0], realVScvtrainCluster.iloc[:,1])     
    confmatcvTest = confusion_matrix(realVScvtestCluster.iloc[:,0], realVScvtestCluster.iloc[:,1])
    
    accuracycvTrain = accuracy_score(realVScvtrainCluster.iloc[:,0], realVScvtrainCluster.iloc[:,1])
    accuracycvTest = accuracy_score(realVScvtestCluster.iloc[:,0], realVScvtestCluster.iloc[:,1])
    recallcvTrain = recall_score(realVScvtrainCluster.iloc[:,0], realVScvtrainCluster.iloc[:,1])
    recallcvTest = recall_score(realVScvtestCluster.iloc[:,0], realVScvtestCluster.iloc[:,1])
    precisioncvTrain = precision_score(realVScvtrainCluster.iloc[:,0], realVScvtrainCluster.iloc[:,1])
    precisioncvTest = precision_score(realVScvtestCluster.iloc[:,0], realVScvtestCluster.iloc[:,1])
    f1ScorecvTrain = f1_score(realVScvtrainCluster.iloc[:,0], realVScvtrainCluster.iloc[:,1])
    f1ScorecvTest = f1_score(realVScvtestCluster.iloc[:,0], realVScvtestCluster.iloc[:,1]) 
    
    completenesscvTrain = completeness_score(realVScvtrainCluster.iloc[:,0], realVScvtrainCluster.iloc[:,1])
    completenesscvTest = completeness_score(realVScvtestCluster.iloc[:,0], realVScvtestCluster.iloc[:,1])
    
    all_acc_Train.append(accuracycvTrain)
    all_acc_Test.append(accuracycvTest)
    all_completeness_Train.append(completenesscvTrain)
    all_completeness_Test.append(completenesscvTest)
    all_recall_Train.append(recallcvTrain)
    all_recall_Test.append(recallcvTest)
    all_precision_Train.append(precisioncvTrain)
    all_precision_Test.append(precisioncvTest)
    all_f1Score_Train.append(f1ScorecvTrain)
    all_f1Score_Test.append(f1ScorecvTest)
    iteration += iteration
    
print("Cross-validated Train accuracy of k-means (cluster = 2) : {} %".format(np.asarray(all_acc_Train).mean()*100))   
print("Cross-validated Test accuracy of k-means (cluster = 2) : {} %".format(np.asarray(all_acc_Test).mean()*100))  
print("Cross-validated Train recall of k-means (cluster = 2) : {} %".format(np.asarray(all_recall_Train).mean()*100))   
print("Cross-validated Test recall of k-means (cluster = 2) : {} %".format(np.asarray(all_recall_Test).mean()*100))
print("Cross-validated Train precision of k-means (cluster = 2) : {} %".format(np.asarray(all_precision_Train).mean()*100))   
print("Cross-validated Test precision of k-means (cluster = 2) : {} %".format(np.asarray(all_precision_Test).mean()*100))
print("Cross-validated Train f1 score of k-means (cluster = 2) : {} %".format(np.asarray(all_f1Score_Train).mean()*100))   
print("Cross-validated Test f1 score of k-means (cluster = 2) : {} %".format(np.asarray(all_f1Score_Test).mean()*100))
print("Cross-validated Train completeness score of k-means (cluster = 2) : {} %".format(np.asarray(all_completeness_Train).mean()*100))   
print("Cross-validated Train completeness score of k-means (cluster = 2) : {} %".format(np.asarray(all_completeness_Test).mean()*100))   
#Completeness metric of a cluster labeling given a ground truth.
#A clustering result satisfies completeness if all the data points that are members of a given class are elements of the same cluster.
#score between 0.0 and 1.0. 1.0 stands for perfectly complete labeling

#------ Building k-means (cluster = 2) with all Train data and making pred on Holdout Test data:
kmeans2 = KMeans(n_clusters = 2, random_state = 0).fit(X_train)
trainCluster = pd.DataFrame(kmeans2.predict(X_train), columns = ['PredictedCluster'])
testCluster = pd.DataFrame(kmeans2.predict(X_test), columns = ['PredictedCluster'])

realVStrainCluster = pd.concat([pd.DataFrame(y_train.values.flatten(), \
     columns = ['Actual']), trainCluster], axis = 1)
realVStestCluster = pd.concat([pd.DataFrame(y_test.values.flatten(), \
     columns = ['Actual']), testCluster], axis = 1)
     
confmatTrain = confusion_matrix(realVStrainCluster.iloc[:,0], realVStrainCluster.iloc[:,1])     
confmatTest = confusion_matrix(realVStestCluster.iloc[:,0], realVStestCluster.iloc[:,1])

accuracyTrain = accuracy_score(realVStrainCluster.iloc[:,0], realVStrainCluster.iloc[:,1])
accuracyTest = accuracy_score(realVStestCluster.iloc[:,0], realVStestCluster.iloc[:,1])
completenessTrain = completeness_score(realVStrainCluster.iloc[:,0], realVStrainCluster.iloc[:,1])
completenessTest = completeness_score(realVStestCluster.iloc[:,0], realVStestCluster.iloc[:,1])
recallTrain = recall_score(realVStrainCluster.iloc[:,0], realVStrainCluster.iloc[:,1])
recallTest = recall_score(realVStestCluster.iloc[:,0], realVStestCluster.iloc[:,1])
precisionTrain = precision_score(realVStrainCluster.iloc[:,0], realVStrainCluster.iloc[:,1])
precisionTest = precision_score(realVStestCluster.iloc[:,0], realVStestCluster.iloc[:,1])
f1scoreTrain = f1_score(realVStrainCluster.iloc[:,0], realVStrainCluster.iloc[:,1])
f1scoreTest = f1_score(realVStestCluster.iloc[:,0], realVStestCluster.iloc[:,1])

print("Final Train accuracy of k-means (cluster = 2) : {} %".format(accuracyTrain*100))   
print("Final Test accuracy of k-means (cluster = 2) : {} %".format(accuracyTest*100))  
print("Final Train completeness score of k-means (cluster = 2) : {} %".format(completenessTrain*100))   
print("Final Test completeness score of k-means (cluster = 2) : {} %".format(completenessTest*100))   
print("Final Train recall score of k-means (cluster = 2) : {} %".format(recallTrain*100))   
print("Final Test recall score of k-means (cluster = 2) : {} %".format(recallTest*100)) 
print("Final Train precision score of k-means (cluster = 2) : {} %".format(precisionTrain*100))   
print("Final Test precision score of k-means (cluster = 2) : {} %".format(precisionTest*100))
print("Final Train f1 score score of k-means (cluster = 2) : {} %".format(f1scoreTrain*100))   
print("Final Test f1 score score of k-means (cluster = 2) : {} %".format(f1scoreTest*100)) 
