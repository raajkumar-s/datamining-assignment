import csv
import numpy as np
import sys
from skfuzzy.cluster import cmeans,cmeans_predict
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score


filename = pd.read_csv(r'C:/Users/derek/Desktop/POC/data/berek.csv')

print(filename)

num_lines = sum(1 for line in open(filename))

trainng_data_count = num_lines*0.7
trainng_data_count = int(round(trainng_data_count))

print('total data count ',num_lines)
print('training data count ',trainng_data_count)

tr = np.genfromtxt(filename, delimiter=',',skip_header=1,skip_footer=(num_lines - trainng_data_count),usecols = (3, 4, 5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22))

cntr,u,u0,d,jm,p,fpc = cmeans(tr.T, 2, 2, .005, 10000, init=None, seed=None)

print('centers');
print(cntr)
#print('/nu')
#print(u)
#print('/nu0')
#print(u0)
#print('/nd')
#print(d)
#print('/njm')
#print(jm)
#print('/np')
#print(p)
#print('/fcp')
#print(fpc);


tst = np.genfromtxt(filename, delimiter=',',skip_header=trainng_data_count,skip_footer=0,usecols = (3, 4, 5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22))



u,u0,d,jm,p,fpc = cmeans_predict(tst.T,cntr, 2, .005, 10, init=None, seed=None)

print("\nu0 test ::")
print(u0)
print("\n1d ::", u[0,:])


actual1 = np.genfromtxt(filename, delimiter=',',skip_header=trainng_data_count,skip_footer=0,usecols = (23))
actual = [1 if i >=1 else 0 for i in actual1]

predict1 = [0 if i >=.5 else 1 for i in u[0,:]]
predict2 = [0 if i >=.5 else 1 for i in u[1,:]]

if accuracy_score(actual,predict1) > accuracy_score(actual,predict2):
	predict = predict1
else:
	predict = predict2

print('------ actual ----------')
print(actual)
print('------ predict ----------')
print(predict)

outputline = ','+ str(accuracy_score(actual,predict))+','+str(precision_score(actual,predict))+','+str(recall_score(actual,predict))+','+str(f1_score(actual,predict))

f=open("out.csv", "a+")
f.write(outputline)
f.close()


