import sys
import csv
import numpy as np
from sklearn import tree
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score


filename = 'data/'+sys.argv[1:][0]

print(filename)

num_lines = sum(1 for line in open(filename))

trainng_data_count = num_lines*0.7
trainng_data_count = int(round(trainng_data_count))

print('total data count ',num_lines)
print('training data count ',trainng_data_count)

tr_input = np.genfromtxt(filename, delimiter=',',skip_header=1,skip_footer=(num_lines - trainng_data_count),usecols = (3, 4, 5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22))

tr_output = np.genfromtxt(filename, delimiter=',',skip_header=1,skip_footer=(num_lines - trainng_data_count),usecols = (23))
tr_output = [1 if i >=1 else 0 for i in tr_output]

clf=tree.DecisionTreeClassifier()
clf.fit(tr_input,tr_output)




tst = np.genfromtxt(filename, delimiter=',',skip_header=trainng_data_count,skip_footer=0,usecols = (3, 4, 5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22))

predict = clf.predict(tst);

actual1 = np.genfromtxt(filename, delimiter=',',skip_header=trainng_data_count,skip_footer=0,usecols = (23))

actual = [1 if i >=1 else 0 for i in actual1]

print('------ actual ----------')
print(actual)

print('------ predict ----------')
print(predict)

outputline = ','+ str(accuracy_score(actual,predict))+','+str(precision_score(actual,predict))+','+str(recall_score(actual,predict))+','+str(f1_score(actual,predict))

f=open("out.csv", "a+")
f.write(outputline)
f.close()
