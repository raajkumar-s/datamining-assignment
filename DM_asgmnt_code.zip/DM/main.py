import os
import glob
from subprocess import call



header1 = "   ,K-means, , , ,FCM, , , ,Decision Tree, , , , Hierarchical clustering, , , ,\n"
header2 = "project,accurecy,precision,recall,fmeasure,accurecy,precision,recall,fmeasure,accurecy,precision,recall,fmeasure,accurecy,precision,recall,fmeasure\n"

f=open("out.csv", "a+")
f.write(header1+header2)
f.close()



rootdir = os.getcwd()

os.chdir(rootdir+'/data')
filenames = glob.glob( '*.csv' )
os.chdir(rootdir)

for name in filenames:
         call(["python", "km.py",name])
         call(["python", "fcm.py",name])
         call(["python", "dt.py",name])       
         call(["python", "hc.py",name])
	 f=open("out.csv", "a+")
	 f.write('\n')
	 f.close()
